package com.MockTestExample;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.StringTokenizer;

public class MockTestExample {
	public static void main(String[] args) {

		try {
			
			File fileObj = new File("C:\\Users\\jfundes\\Desktop\\Pay\\MediaOcean\\TestInput.txt");   // creation of file object for TestInput.txt 

			BufferedReader reader = new BufferedReader(new FileReader(fileObj));     // creation of BufferedReader object to read data from file.

			String line;
			int previousMaxElementIndex = 0;
			int maxNumber = 0, Sum = 0;
			
			// as long as there are lines in the file, read it.
			while ((line = reader.readLine()) != null) {

				StringTokenizer stringTokens = new StringTokenizer(line, "\t");    // Spliting the integers of each line by tab to get all integers of that line.

				int[] numbersArr = new int[stringTokens.countTokens()];     // getting an array of each line which contains all integers of that line

				for (int i = 0; i < numbersArr.length; i++) {
					numbersArr[i] = Integer.parseInt(stringTokens.nextToken());    // Converting String values into Integer array.
				}

				if (numbersArr.length > 1) {  // For more than 1 integers on a line ..)    
					if (numbersArr.length % 2 == 0) {    //To handle even numbers of integers(nodes) on line
						if (numbersArr[previousMaxElementIndex] > numbersArr[previousMaxElementIndex + 1]) {  //condtion to find max number from 2 nodes.
							maxNumber = numbersArr[previousMaxElementIndex];   
							previousMaxElementIndex = previousMaxElementIndex * 2;    //Storing the previous max number index to start the looking for max node from that element(node): for children nodes.
						} else {
							maxNumber = numbersArr[previousMaxElementIndex + 1];
							previousMaxElementIndex = (previousMaxElementIndex + 1) * 2;
						}

					} else {
						maxNumber = numbersArr[previousMaxElementIndex];
						previousMaxElementIndex = previousMaxElementIndex * 2;
					}

				} else if (numbersArr.length == 1) {      // To handle very first node of tree and the node who is having only one child. (Scenario for odd numbers of integers on line)
					maxNumber = numbersArr[previousMaxElementIndex];
					previousMaxElementIndex=previousMaxElementIndex*2;
				}

				Sum = Sum + maxNumber;    // addting Maximum number node to get Sum.
			}

			System.out.println("Sum of Binary Tree is:=   " + Sum);

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

}
